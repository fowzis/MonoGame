﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Breakout
{
    class MathUtil
    {
        public static Vector2 FromPolar(float angle, float magnitude)
        {
            return magnitude * new Vector2((float)Math.Cos(angle), (float)Math.Sin(angle));
        }
        
        // Vector product / Cross product in 2D space
        public static float VectorProduct(Vector2 A, Vector2 B)
        {
            return (A.X * B.Y - A.Y * B.X);
        }

    }
}
