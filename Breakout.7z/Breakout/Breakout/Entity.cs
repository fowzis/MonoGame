﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Breakout
{
    abstract class Entity
    {
        protected Texture2D Image;
        protected Rectangle SourceRect;
        protected Color color = Color.White;
        protected List<LineSegment> segmentsList = new List<LineSegment>();

        public float Orientation;
        public float Radius;            // Used for circular collision detection
        public bool IsExpired;          // true if the entity was destroyed and should be deleted.

        protected Vector2 position;
        public virtual Vector2 Position
        {
            get { return position; }
            set { position = value; }
        }

        protected Vector2 velocity;
        public virtual Vector2 Velocity
        {
            get { return velocity; }
            set { velocity = value; }
        }

        public Vector2 Scale { get; set; }  // Can scale by width and height
        public float Width { get { return SourceRect.Width * Scale.X; } }
        public float Height { get { return SourceRect.Height * Scale.Y; } }
        public float X { get { return Position.X; } }
        public float Y { get { return Position.Y; } }

        public virtual RectangleF Bounds
        {
            get { return new RectangleF(X - Width / 2, Y - Height / 2, Width, Height); }
        }

        public Vector2 Size
        {
            get { return Image == null ? Vector2.Zero : new Vector2(SourceRect.Width, SourceRect.Height); }
        }

        public LineSegment LineSegmentTop
        {
            get { return new LineSegment(new Vector2(Bounds.X, Bounds.Y), new Vector2(Bounds.X + Width, Bounds.Y), BrickSide.Top); }
        }
        public LineSegment LineSegmentRight
        {
            get { return new LineSegment(new Vector2(Bounds.X + Width, Bounds.Y), new Vector2(Bounds.X + Width, Bounds.Y + Height), BrickSide.Right); }
        }
        public LineSegment LineSegmentLeft
        {
            get { return new LineSegment(new Vector2(Bounds.X, Bounds.Y), new Vector2(Bounds.X, Bounds.Y + Height), BrickSide.Left); }
        }
        public LineSegment LineSegmentBottom
        {
            get { return new LineSegment(new Vector2(Bounds.X, Bounds.Y + Height), new Vector2(Bounds.X + Width, Bounds.Y + Height), BrickSide.Bottom); }
        }

        public Entity()
        {
            Image = Art.SpriteSheet;
            Scale = new Vector2(1f);
        }

        public IList<LineSegment> GetBoundSegments()
        {
            segmentsList.Clear();
            segmentsList.Add(LineSegmentTop);
            segmentsList.Add(LineSegmentRight);
            segmentsList.Add(LineSegmentLeft);
            segmentsList.Add(LineSegmentBottom);

            return segmentsList;
        }
        public abstract void Update();

        public virtual void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(
                Image,                  // A texture to be drawn.
                Position,               // The drawing location on the screen.
                SourceRect,             // An optional region which will be rendered. If null - draws full texture.
                color,                  // A color mask.
                Orientation,            // A rotation of this sprite.
                Size / 2f,              // Center of the rotation 0,0 by default.
                Scale,                  // A Scaling of this sprite.
                SpriteEffects.None,     // Modificators for drawing. Can be combined.
                0.0f);                  // A depth of the layer of this sprite.

#if SPRITE_ORIGIN
            spriteBatch.Draw(
                Image,
                Position,
                Art.SRect_Point,
                Color.Black,
                Orientation,
                new Vector2((float)Art.SRect_Point.Width / 2f),
                0.05f,
                SpriteEffects.None,
                0.0f);

            spriteBatch.DrawRectangle(Bounds, Color.Red);
#endif
        }
    }
}
