﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Breakout
{
    class LineSegment
    {
        public Vector2 P1 { get; set; }
        public Vector2 P2 { get; set; }
        public BrickSide BrickSide { get; set; }

        // P1 to P2 gives the correct directio od the vector
        public float Length { get { return (P1 - P2).Length(); } }  // Length or Magnitude ||W|| = sqrt(sqr(dX) + sqr(dY))
        public float Angle { get { return (P1 - P2).ToAngle(); } }  // The Vector angle relative to the 0,0 origin point.

        public LineSegment(Vector2 p1, Vector2 p2, BrickSide brickSide = BrickSide.None)
        {
            this.P1 = p1;
            this.P2 = p2;
            this.BrickSide = brickSide;
        }

        // Check if the Ray emmittig from the ball is intersecting with the bricks
        public Vector2 Intersect(LineSegment ls)
        {
            // Raycasting in 2D (line segment intersection)
            // https://www.youtube.com/watch?v=c065KoXooSw

            Vector2 r = (P1 - P2);
            Vector2 s = (ls.P1 - ls.P2);

            // t,u are the intersection point location relative to the specific line segment
            float t = MathUtil.VectorProduct((ls.P1 - P1), s) / MathUtil.VectorProduct(r, s);
            float u = MathUtil.VectorProduct((ls.P1 - P1), r) / MathUtil.VectorProduct(r, s);

            Vector2 intersectionPoint1 = P1 + t * r;
            Vector2 intersectionPoint2 = ls.P1 + u * s;

            if (s.X == 0)
            {   // Top or Bottom Lines - Parallel to the X axis
                // Check if point in within the segment Y coordinates
                if (intersectionPoint1.Y < ls.P1.Y || intersectionPoint1.Y > ls.P2.Y)
                {
                    return Vector2.Zero;
                }
            }

            if (s.Y == 0)
            {   // Left or Right Lines - Parallel to the Y axis
                // Check if point in within the segment X coordinates
                if (intersectionPoint1.X < ls.P1.X || intersectionPoint1.X > ls.P2.X)
                {
                    return Vector2.Zero;
                }
            }

            return (intersectionPoint1 == intersectionPoint2) ? intersectionPoint1 : Vector2.Zero;
        }

        public bool Intersect(LineSegment ls, out Point intersectionPoint)
        {
            intersectionPoint = Intersect(ls).ToPoint();
            return (intersectionPoint == Point.Zero) ? false : true;
        }

    }
}
