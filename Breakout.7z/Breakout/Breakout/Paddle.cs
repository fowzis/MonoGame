﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Breakout
{
    class Paddle : Entity
    {
        public static Paddle Instance { get; private set; }

        #region Public Properties
        public override Vector2 Position
        {
            get { return position; }
            // Set new position while clamping to screen boundaries
            set { position = Vector2.Clamp(value, Size / 2, Game1.ScreenSize - Size / 2); }
        }
        #endregion

        public Paddle()
        {
            Instance = this;
            SourceRect = Art.SRect_PaddleSmall;

            Radius = SourceRect.Width / 2;

            // Starting position of the paddle
            Position = new Vector2(Game1.Viewport.Width / 2, Game1.Viewport.Height - Art.SRect_PaddleSmall.Height);

            Console.WriteLine("Radius={0}", Radius);

        }

        public override void Update()
        {
            const float speed = 9;
            Velocity += speed * InputHandler.GetMovementDirection();
            Position += Velocity;
            Velocity = Vector2.Zero;
        }
    }
}
