﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Breakout
{
    class Ball : Entity
    {
        private static Random rand = new Random();
        private static Vector2 aim = Vector2.Zero;      // The ball direction vector relative to the (0,0) origin point
        private static Vector2 prevPosition;

        #region Class Properties
        public static Ball Instance { get; private set; }
        public bool Freeze { get; set; }
        public float Speed { get; set; }
        public LineSegment GetRay { get { return new LineSegment(Position, Position + aim); } }
        #endregion

        #region Overriden Properties
        // Veclocity is Speed with direction, or Vector Mangnitude with direction
        public override Vector2 Velocity
        {
            get { return velocity; }
            set { velocity = (Speed * MathUtil.FromPolar(value.ToAngle(), 1f)); }
        }
        #endregion

        public Ball()
        {
            Instance = this;
            SourceRect = Art.SRect_BallSmall;
            Radius = Width / 2;
            Speed = 4;
            Freeze = false;

            // Set initial position
            Position = new Vector2(Game1.Viewport.Width / 2, Game1.Viewport.Height / 2);

            // Set initial velocity and angle
            aim = Vector2.Normalize( new Vector2(rand.Next(0, Game1.Viewport.Width), rand.Next(0, Game1.Viewport.Height)) );
            Velocity = aim;
        }

        public override void Update()
        {
            // If Freeze, don't update
            if (Freeze)
                return;

            // 1. Check Collision with screen borders and deflect the ball
            //HandleBordersCollision(Game1.Viewport.Bounds);

            // 3. Set new position, Update ball movement
            prevPosition = Position;
            Position += Velocity;
            Position = Vector2.Clamp(Position, Size / 2, Game1.ScreenSize - Size / 2);
        }

        public void DeflectX()
        {
            aim.X = -aim.X;
            Velocity = aim;
        }

        public void DeflectY()
        {
            aim.Y = -aim.Y;
            Velocity = aim;
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(
                Image,                  // A texture to be drawn.
                Position,               // The drawing location on the screen.
                SourceRect,             // An optional region which will be rendered. If null - draws full texture.
                color,                  // A color mask.
                Orientation,            // A rotation of this sprite.
                Size / 2f,              // Center of the rotation 0,0 by default.
                1f,                     // A Scaling of this sprite.
                SpriteEffects.None,     // Modificators for drawing. Can be combined.
                0.0f);                  // A depth of the layer of this sprite.

#if SPRITE_ORIGIN
            //spriteBatch.DrawLineSegment(prevPosition, Position, Color.Yellow, 1, Game1.Viewport.Width);
            //spriteBatch.DrawRay(Position, Velocity, Color.Red, 1, Game1.Viewport.Width);
            //spriteBatch.DrawLineSegment(this.GetRay.P1, this.GetRay.P2, Color.Yellow, 1, 1);
            spriteBatch.DrawRay(Position, aim, Color.Yellow, 1, Radius * 100);
            //spriteBatch.DrawRay(Position + new Vector2(Radius,0), aim, Color.Yellow, 1, Radius * 100);
            //spriteBatch.DrawRay(Position + new Vector2(0, Radius), aim, Color.Yellow, 1, Radius * 100);
            spriteBatch.DrawPoint(Position, Color.Blue, 2);
            //spriteBatch.Draw(
            //    Image,                  // A texture to be drawn.
            //    Position,               // The drawing location on the screen.
            //    Art.SRect_Point,        // An optional region in the SriteSheet which will be rendered. If null - draws full texture.
            //    Color.Black,            // A color mask.
            //    Orientation,            // A rotation of this sprite.
            //    new Vector2((float)Art.SRect_Point.Width) / 2f,              // Center of the rotation 0,0 by default.
            //    0.05f,                   // A Scaling of this sprite.
            //    SpriteEffects.None,     // Modificators for drawing. Can be combined.
            //    0.0f);                  // A depth of the layer of this sprite.

            spriteBatch.DrawRectangle(Bounds, Color.Red);
#endif
        }

        #region Commented Code
        //public void HandleBordersCollision(Rectangle bounds)
        //{
        //    // If colliding with the viewport boundaries, deflect the ball
        //    if (X <= Radius || X >= bounds.Width - Radius)
        //    {
        //        aim.X = -aim.X;
        //        Velocity = aim;
        //    }
        //    else if (Y <= Radius || Y >= bounds.Height - Radius)
        //    {
        //        aim.Y = -aim.Y;
        //        Velocity = aim;
        //    }
        //}
        #endregion
    }
}
